<?php
require_once 'conexion.php';
$alias = $_POST['alias'];
$contrasena = $_POST['contrasena'];

$sql = "select idUsuario
	from usuario
	where alias='$alias' and contrasena=SHA('$contrasena')";
$resultado = mysqli_query($conexion, $sql) or die(mysqli_error($conexion));

if ($usuario = mysqli_fetch_array($resultado)) {
    //creamos una sesion para permitir el acceso al sistema
    if (!isset($_SESSION)) {
        session_start();
    }
    $_SESSION['acceso'] = 'permitido';
    $_SESSION['idUsuario'] = $usuario['idUsuario'];
    //Determinar el tipo de usuario
    //Es estudiante
    $sql_est = "select * from estudiante where idUsuario=" . $usuario['idUsuario'];
    $res_est = mysqli_query($conexion, $sql_est) or die(mysqli_error($conexion));
    if ($estudiante = mysqli_fetch_array($res_est)) {
        $_SESSION['tipo'] = "ESTUDIANTE";
        $_SESSION['nombre'] = $estudiante['nombre'];
    } else {
        //Es docente
        $sql_doc = "select * from docente where idUsuario=" . $usuario['idUsuario'];
        $res_doc = mysqli_query($conexion, $sql_doc) or die(mysqli_error($conexion));
        if ($docente = mysqli_fetch_array($res_doc)) {
            $_SESSION['tipo'] = "DOCENTE";
            $_SESSION['nombre'] = $docente['nombre_docente'];
        } else {
            //Es administrador
            $sql_admin = "select * from administrador where idUsuario=" . $usuario['idUsuario'];
            $res_admin = mysqli_query($conexion, $sql_admin) or die(mysqli_error($conexion));
            if ($admin = mysqli_fetch_array($res_admin)) {
                $_SESSION['tipo'] = "ADMINISTRADOR";
                $_SESSION['nombre'] = $admin['nombre_administrador'];
            } else {
                $_SESSION['tipo'] = "NA";
                $_SESSION['nombre'] = "Anonimo";
            }
        }
    }
    echo "OK";
} else {
   echo "Acceso no permitido";
}



