<?php

if (!isset($_SESSION)) {
    session_start();
}

if (isset($_SESSION['tipo'])) {
    switch ($_SESSION['tipo']) {
        case "ADMINISTRADOR":
            require_once "menu_admin.php";
            break;
        case "DOCENTE":
            require_once "menu_docente.php";
            break;
        case "ESTUDIANTE":
            require_once "menu_estudiante.php";
            break;
    }
}

