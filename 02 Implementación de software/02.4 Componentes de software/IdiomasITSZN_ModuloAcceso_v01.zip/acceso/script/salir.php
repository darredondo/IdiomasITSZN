<?php

if (!isset($_SESSION)) {
    session_start();
}
unset($_SESSION['acceso']);
unset($_SESSION['nombre']);
echo "<h1>Hasta luego</h1>";
