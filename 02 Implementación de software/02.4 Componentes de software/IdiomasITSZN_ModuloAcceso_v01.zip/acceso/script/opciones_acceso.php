<?php
if (isset($_GET['accion'])) {
    switch ($_GET['accion']) {
        case 'logout':
            ?>
            <button type="button" class="btn btn-primary" id="BTNingresar">
                <span class="glyphicon glyphicon-user"> Ingresar</span>
            </button>
            <?php
            break;
        case 'login':
            if (!isset($_SESSION)) {
                session_start();
            }
            ?>
            <p class="navbar-text"> 
                <?php echo utf8_decode($_SESSION['nombre']); ?> 
            </p>
            <button type=button class='btn btn-danger' id=BTNsalir>
                <span class='glyphicon glyphicon-log-out'> Salir</span>
            </button>";
            <?php
            break;
    }
}