//Funciones para acceso-----------------------------------
$(document).on('click', '#BTNingresar', function () {
    $('.jumbotron').fadeOut();
    $('#contenido').fadeIn();
    //Cargamos el contenido del script de tabla de clientes
    $('#contenido').load("script/FRMlogin.php");
});

$(document).on('click', '#BTNacceso', function () {
    $('.jumbotron').fadeOut();
    $('#contenido').fadeIn();
    var datos = $('#FRMlogin').serialize();
    //Enviamos los datos al script de guardar cliente
    $.post("script/acceso.php", datos, function (res) {
        if (res == "OK") {
            $("#navegacion").load("script/opciones_acceso.php?accion=login");
            $('#contenido').load("script/menu.php");
        }
        else {
            alert('Acceso no permitido');
            $('#contenido').load("script/FRMlogin.php");
        }
    });
});

$(document).on('click', '#BTNsalir', function () {
    $('.jumbotron').fadeIn();
    //Cargamos el contenido del script de tabla de clientes
    $("#navegacion").load("script/opciones_acceso.php?accion=logout");
    $('#contenido').empty();
    alert('Hasta luego!!');
});