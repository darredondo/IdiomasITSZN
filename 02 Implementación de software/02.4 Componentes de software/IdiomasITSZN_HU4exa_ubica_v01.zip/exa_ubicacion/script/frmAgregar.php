<h1>Ingrese los datos del examen</h1>
<form id=frmRegistrar enctype="multipart/form-data">

    <label for=NoC>No. Control:</label>
    <input type=text name=NoC id=NoC><p>

    <label for=Nombre>Nombre:</label>
    <input type=text name=Nombre id=Nombre><p>

        <label for=Carrera>Carrera:</label>
        <select name="Carrera" id="Carrera">
            <option value="CP">CP</option>
            <option value="IA">IA</option>
            <option value="IEM">IEM</option>
            <option value="IGE">IGE</option>
            <option value="II">II</option>
            <option value="ISC">ISC</option>
            <option value="ITIC">ITIC</option>
            <option value="EXT">EXT</option>
        </select><p>

        <label for=Fecha>Fecha:</label>
        <input type=text name=Fecha id=Fecha> aaaa/mm/dd<p>

        <label for=Nivel>Nivel:</label>
        <input type=text name=Nivel id=Nivel><p>

        <label for=Puntuacion>Puntos:</label>
        <input type=text name=Puntuacion id=Puntuacion><p>

        <label for=NoR>Recibo:</label>
        <input type=text name=NoR id=NoR><p>

        <input type=button value="Guardar Examen" name=BTNguardar class="btn btn-success" id=BTNguardar>
        <input type=button value="Regresar " name=BTNCancelar class="btn btn-primary" id=BTNCancelar>
</form>

<style type="text/css">
    label{
        display:inline-block;
        width:150px;
        margin-left:50px;
        margin-right:5px;
        padding:5px 5px 5px 5px; 
    }
</style>