<H1>Examenes de Ubicación</H1>
<p><input type=button class="btn btn-success" value="Agregar Examen" id=BTNnuevo><p>

<TABLE id=tabla_estudiantes>
    <THREAD>
        <TR>
            <TH>No. Control</TH>
            <TH>Nombre</TH>
            <TH>Carrera</TH>
            <TH>Fecha de Aplicación</TH>
            <TH>Nivel</TH>
            <TH>Puntuación</TH>
            <TH>No. Recibo</TH>
        </TR>   
    </THREAD>
    <TBODY>
        <?php
        $conexion = mysqli_connect("localhost", "user_idiomas", "secret@", "idiomas");
        $sql = "select estudiante.no_control, estudiante.nombre, carrera.siglas, exa_ubicacion.fecha_ubi, exa_ubicacion.nivel_ubi, exa_ubicacion.puntos_ubi, exa_ubicacion.no_recibo from estudiante natural join exa_ubicacion natural join carrera;";
        $consulta = mysqli_query($conexion, $sql) or die(mysqli_error());
        while ($fila = mysqli_fetch_array($consulta)) {
            echo "<TR>";
            echo "<TD>" . $fila[0] . "</TD>";
            echo "<TD>" . $fila[1] . "</TD>";
            echo "<TD>" . $fila[2] . "</TD>";
            echo "<TD>" . $fila[3] . "</TD>";
            echo "<TD>" . $fila[4] . "</TD>";
            echo "<TD>" . $fila[5] . "</TD>";
            echo "<TD>" . $fila[6] . "</TD>";
            echo "</TR>";
        }
        ?>
    </TBODY>
</TABLE>

<SCRIPT>
    $(document).ready(function () {
        $("#tabla_estudiantes").DataTable({
            "bFilter": true,
            "bPaginate": true,
            "bSort": true,
            "bInfo": true
        });
    });
</SCRIPT>