<?php
require_once 'conexion.php';

if (isset($_POST)){
	$NoC = $_POST['NoC'];
	$Nombre = $_POST['Nombre'];
	$Carrera = $_POST['Carrera']; 
	$Fecha = $_POST['Fecha'];
	$Nivel = $_POST['Nivel'];
	$Puntuacion = $_POST['Puntuacion'];
	$NoR = $_POST['NoR'];

	$query = "select idestudiante from estudiante where no_control = '$NoC' and nombre = '$Nombre'";

	$consultaid = mysqli_query($conexion, $query) or die( mysqli_error($conexion));
	$registro = mysqli_fetch_array($consultaid);
	$idestudiante = $registro[0];

	$sql  = "INSERT INTO exa_ubicacion values(null, '$Fecha', '$Nivel', '$Puntuacion', '$NoR', '$idestudiante')";

	mysqli_query($conexion, $sql)  or die( mysqli_error($conexion));

	echo "<h2>Examen guardado</h2>";	
}else{
	echo "<h2> No hay datos</h2>";
}
?>
<input type=button value="Regresar a lista de estudiantes" name=BTNCancelar 
       id=BTNCancelar class="btn btn-primary">