//Funcion para señalar la opcion seleccionada
$(document).on('click', '.opcion', function () {
    $('.opcion').removeClass("active");
    $(this).addClass("active");
});

//opcion de regresar
$(document).on('click', '#BTNregresar', function () {
    window.close();
});

//Funcion agregar examen
$(document).on('click', '#BTNnuevo', function () {
    $("#contenido").load("script/frmAgregar.php");
});
 
//enviar los datos al script de Guardar
$(document).on('click', '#BTNguardar', function () {
    //Empaquetar los datos del formulario
    var datos = new FormData();
    datos.append('NoC', $("#NoC").val());
    datos.append('Nombre', $("#Nombre").val());
    datos.append('Carrera', $("#Carrera").val());
    datos.append('Fecha', $("#Fecha").val());
    datos.append('Nivel', $("#Nivel").val());
    datos.append('Puntuacion', $("#Puntuacion").val());
    datos.append('NoR', $("#NoR").val());
    $.ajax({
        type: "POST",
        url: "script/Guardar.php",
        processData: false,
        contentType: false,
        cache: false,
        data: datos,
        success: function (res) {
            $("#contenido").empty();
            $("#contenido").append(res);
        }
    });
});


//Funcion para regresar el formulario de consulta
$(document).on('click', '#BTNCancelar', function () {
    $('#contenido').load("index.php");
});