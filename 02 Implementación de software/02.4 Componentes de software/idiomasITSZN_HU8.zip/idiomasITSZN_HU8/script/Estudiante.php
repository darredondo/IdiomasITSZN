<?php

//Registro de docente
//Coincide con la tabla Docente de MySQL
class Estudiante {

    public $idestudiante;
    public $no_control;
    public $nombre;
    public $siglas;
    public $fechaubi;
    public $nivel;
    public $semestre;
    public $calificacion;
    public $idusuario;

    public function __construct() {
        
    }

}