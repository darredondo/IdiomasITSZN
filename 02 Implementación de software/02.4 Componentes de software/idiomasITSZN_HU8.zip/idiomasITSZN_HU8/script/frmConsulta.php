<H1>Rol Estudiantil</H1>

<TABLE id=tabla_estudiantes>
    <THEAD>
        <TR>
            <TH>No. Control</TH>
            <TH>Nombre</TH>
            <TH>Carrera</TH>            
            <TH>Nivel Actu&aacute;l</TH>
            <TH>Periodo</TH>
            <TH>Operaciones</TH>
        </TR>   
    </THEAD>
    <TBODY>
        <?php
        $conexion = mysqli_connect("localhost", "user_idiomas", "secret@", "idiomas");
        $sql = "select idestudiante, no_control, nombre, siglas, nivel_curso, semestre from estudiante natural join carrera natural join inscripcion natural join curso;";
        $consulta = mysqli_query($conexion, $sql) or die(mysqli_error());
        while ($fila = mysqli_fetch_array($consulta)) {
            echo "<TR>";            
            echo "<TD>" . $fila[1] . "</TD>";
            echo "<TD>" . $fila[2] . "</TD>";
            echo "<TD>" . $fila[3] . "</TD>";            
            echo "<TD>" . $fila[4] . "</TD>";
            echo "<TD>" . $fila[5] . "</TD>";            
            
            echo "<TD> <input type=button idestudiante=".$fila['idestudiante']." value=Imprimir class='BTNImprimir btn btn-primary'></TD>";
            echo "</TR>";
        }
        ?>
    </TBODY>
</TABLE>

<SCRIPT>
    $(document).ready(function () {
        $("#tabla_estudiantes").DataTable({
            "bFilter": true,
            "bPaginate": true,
            "bSort": true,
            "bInfo": true
        });
    });
</SCRIPT>