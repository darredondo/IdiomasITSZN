<?php

require_once 'SQLestudiante.php';
require_once 'fpdf/fpdf.php'; //Librerías para PDF

class PDF extends FPDF {

    function Titulo() {
        $this->SetFont('Arial', 'B', 14);
        $this->Cell(0, 5, 'INSTITUTO TECNOLOGICO SUPERIOR ZACATECAS NORTE', 1, 0, 'C');
        $this->Ln();
        $this->SetFont('Arial', 'I', 12);
        $this->Cell(0, 5, 'CENTRO DE IDIOMAS', 0, 0, 'C');
        $this->Ln(20);
    }

    function Cuerpo($id) {
        $SQL = new SQLestudiante();
        $lista = $SQL->obtenerEstudiante($id);
        //Mostramos cada docente en una tabla en el PDF
        $this->SetFont('Arial', '', 10);
        // Cabecera, cada par es el titulo y ancho de cada columna
        $encabezados = array(
            "No. Control" => 20,
            "Nombre" => 63,
            "Carrera" => 14,
            "Fecha de Examen de Ubicacion" => 52,
            "Nivel" => 10,
            "Periodo" => 22,
            "Calificacion" => 20
        );

        foreach ($encabezados as $titulo => $ancho) {
            $this->Cell($ancho, 7, $titulo, 1);
        }
        $this->Ln();
        //Filas de datos
        foreach ($lista as $mEstudiante) {        
            $this->Cell(20, 7, utf8_decode($mEstudiante->no_control), 1);
            $this->Cell(63, 7, utf8_decode($mEstudiante->nombre), 1);
            $this->Cell(14, 7, utf8_decode($mEstudiante->siglas), 1);
            $this->Cell(52, 7, utf8_decode($mEstudiante->fechaubi), 1);
            $this->Cell(10, 7, utf8_decode($mEstudiante->nivel), 1);
            $this->Cell(22, 7, utf8_decode($mEstudiante->semestre), 1);
            $this->Cell(20, 7, utf8_decode($mEstudiante->calificacion), 1);

            $this->Ln();
        }
    }

    function PiePagina() {
        $this->Ln(20);
        $this->Cell(0, 10, 'ATENTAMENTE', 0, 0, 'C');
        $this->Ln(15);
        $this->Cell(0, 10, '____________________________________', 0, 0, 'C');
        $this->Ln(5);
        $this->Cell(0, 10, 'MARTHA PATRICIA OZORNIO GONZALEZ', 0, 0, 'C');
        $this->Ln(5);
        $this->Cell(0, 10, 'JEFE DEL DEPARTAMENTO DE SERVICIOS ESCOLARES', 0, 0, 'C');
    }

}

if (isset($_GET['idEstudiante'])){
    $idEstudiante = $_GET['idEstudiante'];

    //Generar el PDF
    $pdf = new PDF();
    $pdf->SetMargins(5, 15, 5);
    $pdf->AddPage();
    $pdf->Titulo();
    $pdf->Cuerpo($idEstudiante);
    $pdf->PiePagina();
    $pdf->Output();
}else {
    echo "Imposible generar calificaci&oacute;n estudiante inexistente";
}