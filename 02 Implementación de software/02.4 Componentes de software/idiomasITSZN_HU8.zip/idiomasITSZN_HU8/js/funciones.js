//Funcion para señalar la opcion seleccionada
$(document).on('click', '.opcion', function () {
    $('.opcion').removeClass("active");
    $(this).addClass("active");
});

//Opcion de regresar
$(document).on('click', '#BTNregresar', function () {
    window.close();
});

$(document).on('click', '.BTNImprimir', function () {
    var idEstudiante=$(this).attr('idestudiante');
    openNewTab("./script/PDFalumnocali.php?idEstudiante="+idEstudiante);
});

function openNewTab(url) {
    var win = window.open(url, '_blank');
    if (win) {
        //Browser has allowed it to be opened
        win.focus();
    } else {
        //Browser has blocked it
        alert('Please allow popups for this website');
    }
}