<?php
require_once 'conexion.php';

if (isset($_POST['idestudiante'])) {
    $idestudiante = $_POST['idestudiante'];
    $NoC = $_POST['NoC'];
    $Nombre = $_POST['Nombre'];

    $sql = "UPDATE estudiante SET no_control = '$NoC', nombre = '$Nombre' WHERE idestudiante = '$idestudiante'";
    mysqli_query($conexion, $sql) or die(mysqli_error($conexion));
    echo "<h2>Estudiante modificado</h2>";
} else {
    echo "No hay datos";
}
?>
<input type=button value="Regresar a lista de estudiantes" name=BTNCancelar 
       id=BTNCancelar class="btn btn-primary">