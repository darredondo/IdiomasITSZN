<h1>Consulta estudiantes</h1>
<p><input type=button class="btn btn-success" value="Nuevo estudiante" id=BTNnuevo_est><p>
<table id=tabla_estudiantes>
    <thead>
        <tr>

            <th>No. Control</th>
            <th>Nombre</th>
            <th>Carrera</th>
            <th>Operaciones</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $conexion = mysqli_connect("localhost", "user_idiomas", "secret@", "idiomas");
        $sql = "select * from estudiante natural join carrera";
        $consulta = mysqli_query($conexion, $sql) or die(mysqli_error());
        while ($fila = mysqli_fetch_array($consulta)) {
            echo "<tr>";
            //echo "<td>".$fila[1]."</td>";
            echo "<td>" . $fila[2] . "</td>";
            echo "<td>" . $fila[3] . "</td>";
            echo "<td>" . $fila[5] . "</td>";
            echo "<td> 
                  <input type=button idestudiante=" . $fila[1] . " value=Modificar class='BTNModificar_est btn btn-warning'>
                  <input type=button idestudiante=" . $fila[1] . " value=Eliminar class='BTNeliminar_est btn btn-danger'>
                  </td>";
            echo "</tr>";
        }
        ?>
    </tbody>
</table>

<script>
    $(document).ready(function () {
        $("#tabla_estudiantes").DataTable({
            "bFilter": true,
            "bPaginate": true,
            "bSort": true,
            "bInfo": true
        });
    });
</script>