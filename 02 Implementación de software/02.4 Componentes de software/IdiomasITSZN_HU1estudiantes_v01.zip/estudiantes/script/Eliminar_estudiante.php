<?php
require_once 'conexion.php';
//Asegurar que recibimos información
if (isset($_POST['idestudiante'])) {
    //Obtenemos los datos del POST
    $idestudiante = $_POST['idestudiante'];
    //Conectamos con la base de datos
    $sql = "delete from estudiante where idestudiante = $idestudiante";
    mysqli_query($conexion, $sql) or die(mysqli_error());
    echo "<h2>Estudiante eliminado</h2>";
}
?>
<input type=button value="Regresar a lista de estudiantes" name=BTNCancelar 
       id=BTNCancelar class="btn btn-primary">