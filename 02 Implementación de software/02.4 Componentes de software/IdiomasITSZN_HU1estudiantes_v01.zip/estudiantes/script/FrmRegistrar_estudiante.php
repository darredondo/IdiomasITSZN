<h1>Ingrese los datos del nuevo estudiante</h1>
<form id=FrmRegistrar_estudiante enctype="multipart/form-data">

    <label for=NoC>No. Control:</label>
    <input type=text name=NoC id=NoC><p>

        <label for=Nombre>Nombre:</label>
    <input type=text name=Nombre id=Nombre><p>

        <label for=Carrera>Carrera:</label>
        <select name="Carrera" id="Carrera">
            <option value="CP">CP</option>
            <option value="IA">IA</option>
            <option value="IEM">IEM</option>
            <option value="IGE">IGE</option>
            <option value="II">II</option>
            <option value="ISC">ISC</option>
            <option value="ITIC">ITIC</option>
            <option value="EXT">EXT</option>
        </select><p>

        <label for=Alias>Alias:</label>
    <input type=text name=Alias id=Alias><p>

        <label for=Contrasena>Contraseña:</label>
    <input type=password name=Contrasena id=Contrasena><p>

        <input type=button value="Guardar estudiante" name=BTNguardar_est class="btn btn-success" id=BTNguardar_est>
        <input type=button value="Regresar a lista de estudiantes" name=BTNCancelar 
               id=BTNCancelar class="btn btn-primary">
</form>

<style type="text/css">
    label{
        display:inline-block;
        width:150px;
        margin-left:50px;
        margin-right:5px;
        padding:5px 5px 5px 5px; 
    }
</style>