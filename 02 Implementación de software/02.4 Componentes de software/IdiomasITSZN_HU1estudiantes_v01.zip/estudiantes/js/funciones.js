//Funcion para señalar la opcion seleccionada
$(document).on('click', '.opcion', function () {
    $('.opcion').removeClass("active");
    $(this).addClass("active");
});

//opcion de regresar
$(document).on('click', '#BTNregresar', function () {
    window.close();
});

//Funciones de estudiante
//Funcion para mostrar el formulario de nuevo estudiante 
//cuando presione el boton "Nuevo estudiante"}
$(document).on('click', '#BTNnuevo_est', function () {
    $("#contenido").load("script/FrmRegistrar_estudiante.php");
});

//Al dar click en el boton de "Guardar estudiante", 
//enviar los datos al scritp de Guardar_estudiante
$(document).on('click', '#BTNguardar_est', function () {
    //Empaquetar los datos del formulario
    var datos = new FormData();
    datos.append('Alias', $("#Alias").val());
    datos.append('Contrasena', $("#Contrasena").val());
    datos.append('NoC', $("#NoC").val());
    datos.append('Nombre', $("#Nombre").val());
    datos.append('Carrera', $("#Carrera").val());
    $.ajax({
        type: "POST",
        url: "script/Guardar_estudiante.php",
        processData: false,
        contentType: false,
        cache: false,
        data: datos,
        success: function (res) {
            $("#contenido").empty();
            $("#contenido").append(res);
        }
    });
});

//Al dar click en el boton "Eliminar"
//enviar el id del articulo al script para eliminar_estudiante
$(document).on('click', '.BTNeliminar_est', function () {
    var idestudiante = $(this).attr('idestudiante');
    var resp = confirm('Este estudiante sera eliminado permanentemente \n ¿Desea continuar? ');
    if (resp) {
        //Enviamos el id del estudiante a eliminar al script
        $.post("script/Eliminar_estudiante.php", {idestudiante: idestudiante},
        function (res) {
            if (res != false) {
                $("#contenido").empty();
                $("#contenido").append(res);
            }
        });
    }
    $('#contenido').load("script/FrmConsulta_estudiantes.php");
});

//Al dar click en el boton modificar de la consulta estudiantes ,enviar el id del estudiante
//Mostar el formualario con los datos formular
$(document).on('click', '.BTNModificar_est', function () {
    var idestudiante = $(this).attr('idestudiante');
    $("#contenido").load("script/FrmRegistrar_estudiante.php");
    $.post("script/FrmModificar_estudiante.php", {idestudiante: idestudiante}, function (res) {
        $("#contenido").empty();
        $("#contenido").append(res);
    });
});

//Al dar click en el boton de "Modificar estudiante", 
//enviar los datos al scritp de Modificar estudiante
$(document).on('click', '#BTNactualizar_est', function () {
    var datos = new FormData();
    datos.append('idestudiante', $("#idestudiante").val());
    datos.append('NoC', $("#NoC").val());
    datos.append('Nombre', $("#Nombre").val());
    $.ajax({
        type: "POST",
        url: "script/Modificar_estudiante.php",
        processData: false,
        contentType: false,
        cache: false,
        data: datos,
        success: function (res) {
            $("#contenido").empty();
            $("#contenido").append(res);
        }
    });
});

//Funcion para regresar el formulario de consulta estudiantes
//cuando presione el boton "Cancelar"}
$(document).on('click', '#BTNCancelar', function () {
    $('#contenido').load("script/FrmConsulta_estudiantes.php");
});