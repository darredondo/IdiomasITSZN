<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Sistema gestion centro de idiomas</title>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/estilos.css">
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/funciones.js"></script>
        <script type="text/javascript" src="js/jquery.dataTables.js" ></script>
        <link rel="stylesheet" type="text/css" href="js/jquery.dataTables.css" />
    </head>
    <body >
        <header>
            <nav class="navbar navbar-inverse navbar-static-top" role="navigation">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navegacion-fm">
                            <span class="sr-only">Desplegar / Ocultar Menu</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a href="http://<?php echo $_SERVER['HTTP_HOST']; ?>/idiomas" class="navbar-brand">Sistema Gestion Idiomas</a>
                    </div>
                    <!-- Inicia Menu -->
                    <div class="collapse navbar-collapse" id="navegacion-fm">
                        <form class="navbar-form navbar-right" id="navegacion">
                            <button type=button class='btn btn-block' id=BTNregresar>
                                <span class='glyphicon glyphicon-backward'> Regresar</span>
                            </button>
                        </form>
                    </div>
                </div>
            </nav>
        </header>

        <section class="main">
            <div id="contenido">
                <?php
                //Aqui especificamos el primer script que se motrará en el módulo
                require_once 'script/tablaDocentes.php';
                ?>
            </div>

            <div id="footer" align="center">
                Instituto Tecnológico Superior Zacatecas Norte. Centro de Desarrollo y Capacitación.
            </div>

        </section>

    </body>
</html>