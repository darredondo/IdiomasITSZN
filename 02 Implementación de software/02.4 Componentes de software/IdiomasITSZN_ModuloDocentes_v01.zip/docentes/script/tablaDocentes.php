<h1>Lista de docentes</h1>
<p><input type=button class="btn btn-success" value="Nuevo docente" id=BTNnuevo_doc><p>
<table id=tabla_docentes>
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Operaciones</th>
        </tr>
    </thead>
    <tbody>
        <?php
        require_once 'SQLdocente.php';
        $SQL = new SQLdocente();
        $lista = $SQL->obtenerListaDocentes();
        //Mostramos cada docente en el cuerpo de la tabla
        foreach ($lista as $mDocente) {
            echo "<tr>";
            echo "<td>" . $mDocente->nombre_docente . "</td>";
            //Generamos los botones para modificar o eliminar un docente
            // usando su iddocente
            echo "<td> 
                  <input type=button iddocente=" . $mDocente->iddocente . " 
                      value=Modificar class='BTNmodificar_doc btn btn-warning'>
                  <input type=button iddocente=" . $mDocente->iddocente . " 
                      value=Eliminar class='BTNeliminar_doc btn btn-danger'>
                  </td>";
            echo "</tr>";
        }
        ?>
    </tbody>
</table>

<!--Aplicamos el plugin de DataTables a la tabla usando su ID -->
<script>
    $(document).ready(function () {
        $("#tabla_docentes").DataTable({
            "bFilter": true,
            "bPaginate": true,
            "bSort": true,
            "bInfo": true
        });
    });
</script>