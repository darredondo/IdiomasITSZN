<h1>Ingrese los datos del nuevo docente</h1>
<form id=FRMdocente >
    <label for=nombre>Nombre completo:</label>
    <input type=text name=nombre id=nombre size="50"><p>
        <label for=alias>Alias:</label>
    <input type=text name=alias id=alias><p>
        <label for=contrasena>Contraseña:</label>
    <input type=password name=contrasena id=contrasena><p>

        <input type=button value="Guardar docente" name=BTNguardar_doc class="btn btn-success" id=BTNguardar_doc>
        <input type=button value="Regresar a lista de docentes" name=BTNcancelar 
               id=BTNcancelar class="btn btn-primary">
</form>

<style type="text/css">
    label{
        display:inline-block;
        width:150px;
        margin-left:50px;
        margin-right:5px;
        padding:5px 5px 5px 5px; 
    }
</style>