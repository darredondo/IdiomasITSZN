<?php

//Registro de docente
//Coincide con la tabla Docente de MySQL
class Docente {

    public $iddocente;
    public $nombre_docente;
    public $idusuario;
    public $alias;
    public $contrasena;

    public function __construct() {
        
    }

}
