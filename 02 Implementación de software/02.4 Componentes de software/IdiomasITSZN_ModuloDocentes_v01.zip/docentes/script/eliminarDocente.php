<?php
require_once 'SQLdocente.php';
//Asegurar que recibimos información
if (isset($_POST['iddocente'])) {
    //Obtenemos los datos del POST
    $iddocente = $_POST['iddocente'];
    $SQL=new SQLdocente();
    $SQL->eliminarDocente($iddocente);
    echo "<h2>Docente eliminado</h2>";
}
?>
<input type=button value="Regresar a lista de docentes" name=BTNcancelar 
       id=BTNcancelar class="btn btn-primary">