<?php
require_once 'SQLdocente.php';

if (isset($_POST)) {
    $mDocente=new Docente();
    $mDocente->nombre_docente = $_POST['nombre'];
    $mDocente->alias = $_POST['alias'];
    $mDocente->contrasena = $_POST['contrasena'];
    
    $SQL=new SQLdocente();
    $SQL->agregarDocente($mDocente);
    echo "<h2>Docente guardado</h2>";
} else {
    echo "<h2>Error - No se puedo guardar los datos</h2>";
}
?>
<input type=button value="Regresar a lista de docentes" name=BTNcancelar 
       id=BTNcancelar class="btn btn-primary">