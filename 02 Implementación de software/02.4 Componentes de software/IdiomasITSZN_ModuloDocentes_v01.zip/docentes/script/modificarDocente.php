<?php
require_once 'SQLdocente.php';

if (isset($_POST['iddocente'])) {
    $mDocente=new Docente();
    $mDocente->iddocente = $_POST['iddocente'];
    $mDocente->nombre_docente = $_POST['nombre'];
    
    $SQL=new SQLdocente();
    $SQL->modificarDocente($mDocente);
    echo "<h2>Docente modificado</h2>";
} else {
    echo "Error - No se pudo modificar el docente";
}
?>
<input type=button value="Regresar a lista de docentes" name=BTNcancelar 
       id=BTNcancelar class="btn btn-primary">