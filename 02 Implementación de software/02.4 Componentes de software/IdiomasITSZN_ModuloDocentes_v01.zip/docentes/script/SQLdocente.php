<?php

require_once 'conexion.php';
require_once 'Docente.php';
/*
 * Funciones de gestion de datos de docentes
 */

class SQLdocente {

    public function __construct() {
        
    }

    public function obtenerListaDocentes() {
        $conexion = conectar();
        $lista = array();
        //Esta linea es para que puedan mostrarse ñ y acentos
        mysqli_query($conexion, "SET NAMES 'utf8'");
        $sql = "select * from docente";
        $consulta = mysqli_query($conexion, $sql) or die(mysqli_error());
        //Mostramos cada docente en el cuerpo de la tabla
        while ($fila = mysqli_fetch_array($consulta)) {
            $mDocente = new Docente();
            $mDocente->iddocente = $fila['iddocente'];
            $mDocente->nombre_docente = $fila['nombre_docente'];
            $mDocente->idusuario = $fila['idusuario'];
            array_push($lista, $mDocente);
        }
        return $lista;
    }

    public function obtenerDocente($iddocente) {
        $conexion = conectar();
        //Esta linea es para que puedan mostrarse ñ y acentos
        mysqli_query($conexion, "SET NAMES 'utf8'");
        $sql = "SELECT * FROM docente where iddocente = '$iddocente'";
        $consulta = mysqli_query($conexion, $sql) or die(mysqli_error($conexion));
        //Mostramos cada docente en el cuerpo de la tabla
        $mDocente = new Docente();
        if ($fila = mysqli_fetch_array($consulta)) {
            $mDocente->iddocente = $fila['iddocente'];
            $mDocente->nombre_docente = $fila['nombre_docente'];
            $mDocente->idusuario = $fila['idusuario'];
        }
        return $mDocente;
    }

    public function agregarDocente($docenteNuevo) {
        $conexion = conectar();
        //Encapsulamos una transaccion para asegurar que el docente y su usuario 
        //sean registrados de manera coherente
        mysqli_query($conexion, "START TRANSACTION") or die(mysqli_error($conexion));
        $sqlUsuario = "INSERT INTO usuario values(null, '$docenteNuevo->alias', "
                . "sha('$docenteNuevo->contrasena'))";
        mysqli_query($conexion, $sqlUsuario) or die(mysqli_error($conexion));
        $sqlDocente = "INSERT INTO docente values(null, '$docenteNuevo->nombre_docente', "
                . "(select idusuario from usuario where alias='$docenteNuevo->alias' limit 1))";
        mysqli_query($conexion, $sqlDocente) or die(mysqli_error());
        mysqli_query($conexion, "COMMIT") or die(mysqli_error($conexion));
    }

    public function modificarDocente($docenteMod) {
        $conexion = conectar();
        $sql = "UPDATE docente SET nombre_docente = '$docenteMod->nombre_docente' "
                . " WHERE iddocente = '$docenteMod->iddocente'";
        mysqli_query($conexion, $sql) or die(mysqli_error($conexion));
    }

    public function eliminarDocente($iddocente) {
        $conexion = conectar();
        //Encapsulamos una transaccion para asegurar que el docente y su usuario 
        //sean borrados de manera coherente
        mysqli_query($conexion, "START TRANSACTION") or die(mysqli_error($conexion));
        $sqlUsuario = "delete from usuario where idusuario = "
                . "( select idusuario from docente where iddocente=$iddocente limit 1)";
        mysqli_query($conexion, $sqlUsuario) or die(mysqli_error());
        $sqlDocente = "delete from docente where iddocente = $iddocente";
        mysqli_query($conexion, $sqlDocente) or die(mysqli_error());
        mysqli_query($conexion, "COMMIT") or die(mysqli_error($conexion));
    }

}
