<?php
require_once 'SQLdocente.php';

if (isset($_POST['iddocente'])) {
    $SQL = new SQLdocente();
    $mDocente = $SQL->obtenerDocente($_POST['iddocente']);
} else {
    $mDocente = new Docente();
}
?>
<h1>Modificaci&oacute;n de datos</h1>
<form id=FRMdocente_mod enctype="multipart/form-data">
    <input type="hidden" name="iddocente" id="iddocente" 
           value="<?php echo $mDocente->iddocente; ?>">
    <label for=Nombre>Nombre:</label>
    <input type=text name=nombre id=nombre  
           value="<?php echo $mDocente->nombre_docente; ?>" size="50"><br>
    <input type=button value="Actualizar docente" name=BTNactualizar_doc 
           id=BTNactualizar_doc class="btn btn-success">
    <input type=button value="Regresar a lista de docentes" name=BTNCancelar 
           id=BTNcancelar class="btn btn-primary">
</form>

<style type="text/css">
    label{
        display:inline-block;
        width:150px;
        margin-left:50px;
        margin-right:5px;
        padding:5px 5px 5px 5px; 
    }
</style>