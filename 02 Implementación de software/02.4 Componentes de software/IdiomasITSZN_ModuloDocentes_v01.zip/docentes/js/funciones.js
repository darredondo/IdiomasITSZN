//Funcion para señalar la opcion seleccionada
$(document).on('click', '.opcion', function () {
    $('.opcion').removeClass("active");
    $(this).addClass("active");
});

//opcion de regresar
$(document).on('click', '#BTNregresar', function () {
    window.close();
});

//Funciones de docente
//Funcion para mostrar el formulario de nuevo docente 
//cuando presione el boton "Nuevo docente"}
$(document).on('click', '#BTNnuevo_doc', function () {
    $("#contenido").load("script/FRMnuevoDocente.php");
});

//Al dar click en el boton de "Guardar docente", 
//enviar los datos al scritp de Guardar_docente
$(document).on('click', '#BTNguardar_doc', function () {
    //Empaquetar los datos del formulario
    var datos = $("#FRMdocente").serialize();
    $.post("script/guardarDocente.php", datos, function (res) {
        $("#contenido").empty();
        $("#contenido").append(res);
        
    });
});

//Al dar click en el boton "Eliminar"
//enviar el id del articulo al script para eliminar_docente
$(document).on('click', '.BTNeliminar_doc', function () {
    var iddocente = $(this).attr('iddocente');
    var resp = confirm('Este docente sera eliminado permanentemente \n ¿Desea continuar? ');
    if (resp) {
        //Enviamos el id del docente a eliminar al script
        $.post("script/eliminarDocente.php", {iddocente: iddocente},
        function (res) {
            if (res != false) {
                $("#contenido").empty();
                $("#contenido").append(res);
            }
        });
    }
    $('#contenido').load("script/tablaDocentes.php");
});

//Al dar click en el boton modificar de la consulta docentes ,enviar el id del docente
//Mostar el formualario con los datos a modificar
$(document).on('click', '.BTNmodificar_doc', function () {
    var iddocente = $(this).attr('iddocente');
    $.post("script/FRMmodificarDocente.php", {iddocente: iddocente}, function (res) {
        $("#contenido").empty();
        $("#contenido").append(res);
    });
});

//Al dar click en el boton de "Modificar docente", 
//enviar los datos al scritp de Modificar docente
$(document).on('click', '#BTNactualizar_doc', function () {
    //Empaquetar los datos del formulario
    var datos = $("#FRMdocente_mod").serialize();
    $.post("script/modificarDocente.php", datos, function (res) {
        $("#contenido").empty();
        $("#contenido").append(res);
    });
});

//Funcion para regresar el formulario de consulta docentes
//cuando presione el boton "Cancelar"}
$(document).on('click', '#BTNcancelar', function () {
    $('#contenido').load("script/tablaDocentes.php");
});