//ESTUDIANTES-------------------------------------------------
$(document).on('click', '#catalogo', function(){
  $('.banner').fadeOut();
  $('.page').fadeIn();
  //Cargamos el contenido del script de tabla de articulos
  $('.page').load("script/FrmConsulta_estudiantes.php");
});
//Funcion para mostrar el formulario de nuevo estudiante 
//cuando presione el boton "Nuevo estudiante"}
$(document).on('click', '#BTNnuevo_est', function(){
	$(".page").load("script/FrmRegistrar_estudiante.php");
});

//Al dar click en el boton de "Guardar estudiante", 
//enviar los datos al scritp de Guardar_estudiante
$(document).on('click', '#BTNguardar_est', function(){
    //Empaquetar los datos del formulario
    var datos=new FormData();
    datos.append('Alias', $("#Alias").val());
    datos.append('Contrasena', $("#Contrasena").val());
    datos.append('NoC', $("#NoC").val());
    datos.append('Nombre', $("#Nombre").val());
    datos.append('Carrera', $("#Carrera").val());
    $.ajax({
    	type: "POST",
    	url:"script/Guardar_estudiante.php",
    	processData:false,
    	contentType:false,
    	cache:false,
    	data: datos,
    	success: function(res){
    		$(".page").empty();
    		$(".page").append(res);
    	}
    });
});

//Al dar click en el boton "Eliminar"
//enviar el id del articulo al script para eliminar_estudiante
$(document).on('click', '.BTNeliminar_est', function(){
   var idestudiante=$(this).attr('idestudiante');
   var resp=confirm('Este estudiante sera eliminado permanentemente \n ¿Desea continuar? ');
   if(resp){
   	//Enviamos el id del estudiante a eliminar al script
   	   $.post("script/Eliminar_estudiante.php", {idestudiante:idestudiante},
   	   	  function(res){
   	   	  	if(res!=false){
   	   	  		$(".page").empty();
    			   $(".page").append(res);
   	   	  	}
   	   	  });
    }
    $('.page').load("script/FrmConsulta_estudiantes.php");
});

//Al dar click en el boton modificar de la consulta estudiantes ,enviar el id del estudiante
//Mostar el formualario con los datos formular
$(document).on('click','.BTNModificar_est', function(){
	var idestudiante=$(this).attr('idestudiante');
    $(".page").load("script/FrmRegistrar_estudiante.php");
	$.post("script/FrmModificar_estudiante.php",{idestudiante:idestudiante}, function(res){
		$(".page").empty();
		$(".page").append(res);
	});
});

//Al dar click en el boton de "Modificar estudiante", 
//enviar los datos al scritp de Modificar estudiante
$(document).on('click', '#BTNactualizar_est', function(){
    var datos=new FormData();
    datos.append('idestudiante', $("#idestudiante").val());
    datos.append('NoC', $("#NoC").val());
    datos.append('Nombre', $("#Nombre").val());
    $.ajax({
        type: "POST",
        url:"script/Modificar_estudiante.php",
        processData:false,
        contentType:false,
        cache:false,
        data: datos,
        success: function(res){
            $(".page").empty();
            $(".page").append(res);
        }
    });
});

//Funcion para regresar el formulario de consulta estudiantes
//cuando presione el boton "Cancelar"}
$(document).on('click', '#BTNCancelar', function(){
    $('.page').load("script/FrmConsulta_estudiantes.php");
});

//Funcion para regresar el formulario de consulta estudiantes
//cuando presione el boton "Cancelar"}
$(document).on('click', '#BTNCancelarE', function(){
    $('.page').load("script/FrmConsulta_estudiantes.php");
});