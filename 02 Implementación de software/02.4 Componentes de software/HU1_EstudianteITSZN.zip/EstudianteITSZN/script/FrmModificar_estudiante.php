<h1>Modificacion de datos</h1>
<form id=FrmModificar_estudiante enctype="multipart/form-data">

<?php
$idestudiante  = $_POST['idestudiante'];

$conexion=mysqli_connect("localhost", "user_idiomas", "secret@", "idiomas");

$sql = "SELECT * FROM estudiante where idestudiante = '$idestudiante'";
$consulta=mysqli_query($conexion, $sql) or die(mysqli_error($conexion));

$fila = $consulta->fetch_assoc()
?>

<label for=NoC>No. Control:</label>

<input type="hidden" name="idestudiante" id="idestudiante" value="<?php echo $fila['idestudiante'];?>">

<input type=text name=NoC id=NoC value="<?php echo $fila['no_control']; ?>"><p>

<label for=Nombre>Nombre:</label>
<input type=text name=Nombre id=Nombre  value="<?php echo $fila['nombre']?>"><p>

<input type=button value="Actualizar estudiante" name=BTNactualizar_est id=BTNactualizar_est>
<input type=button value="Cancelar" name=BTNCancelar id=BTNCancelar>
</form>

<style type="text/css">
   label{
      display:inline-block;
      width:150px;
      margin-left:50px;
      margin-right:5px;
      padding:5px 5px 5px 5px; 
   }
</style>