<?php
//Asegurar que recibimos información
   if(isset($_POST)){
   		//Obtenemos los datos del POST
      $idestudiante = $_POST['idestudiante'];
   		//Conectamos con la base de datos
   $conexion=mysqli_connect("localhost", "user_idiomas", "secret@", "idiomas") or die( mysqli_error());

   		//Eliminamos los datos usando SQL
   		$sql="delete from estudiante where idestudiante = $idestudiante";
      mysqli_query($conexion, $sql) or die( mysqli_error());
		  echo "<h2>Estudiante eliminado</h2>";
      echo $Eliminacion;
    }
?>