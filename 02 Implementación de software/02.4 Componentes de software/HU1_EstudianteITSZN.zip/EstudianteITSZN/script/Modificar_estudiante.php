<?php

if(isset($_POST)){
	$idestudiante=$_POST['idestudiante'];
	$NoC = $_POST['NoC'];
	$Nombre=$_POST['Nombre'];

	$conexion=mysqli_connect("localhost", "user_idiomas", "secret@", "idiomas") or die( mysqli_error());
	
	$sql="UPDATE estudiante SET no_control = '$NoC', nombre = '$Nombre' WHERE idestudiante = '$idestudiante'";
	mysqli_query($conexion, $sql) or die(mysqli_error($conexion));
	echo "<h2>estudiante modificado</h2>";
}else{
	echo "No hay datos";
}
?>