<?php
if (isset($_POST)){
	$NoC = $_POST['NoC'];
	$Nombre=$_POST['Nombre'];
	$Carrera=$_POST['Carrera']; 
	$Alias = $_POST['Alias'];
	$Contrasena = $_POST['Contrasena'];

	$conexion=mysqli_connect("localhost", "user_idiomas", "secret@", "idiomas");

	$query1 = "INSERT INTO usuario values(null, '$Alias', '$Contrasena')";

	mysqli_query($conexion, $query1)  or die( mysqli_error($conexion));

	$query2 = "select max(idusuario) from usuario";

	$consultamax = mysqli_query($conexion, $query2) or die (mysqli_error());
	$registro = mysqli_fetch_array($consultamax);
	$max = $registro[0];

	$query3 = "select idcarrera from carrera where siglas = '$Carrera'";

	$consultaid = mysqli_query($conexion, $query3) or die( mysqli_error());
	$registro2 = mysqli_fetch_array($consultaid);
	$idCarrera = $registro2[0];

	$sql  = "INSERT INTO estudiante values(null, '$NoC',
   			'$Nombre',$idCarrera, $max)";

	mysqli_query($conexion, $sql)  or die( mysqli_error());

	echo "<h2>Esudiante guardado</h2>";	
}else{
	echo "<h2> No hay datos</h2>";
}
?>