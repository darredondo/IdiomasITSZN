<?php

function conectar() {
//Configuramos los parametros de conexión
    $servidor = "localhost";
    $baseDatos = "idiomas";
    $usuario = "user_idiomas";
    $contrasenna = "secret@";
//conectamos con la BD
    $conexion = mysqli_connect($servidor, $usuario, $contrasenna, $baseDatos)
            or die(mysqli_error($conexion));
    return $conexion;
}
