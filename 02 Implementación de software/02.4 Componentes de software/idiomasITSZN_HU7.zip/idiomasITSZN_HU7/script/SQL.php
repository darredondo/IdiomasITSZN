<?php

require_once 'conexion.php';
require_once 'Estudiante.php';
require_once 'Docente.php';
/*
 * Funciones de gestion de datos de docentes
 */

class SQL {

    public function __construct() {
        
    }

    public function obtenerEstudiante($iddocente, $sistema) {
        $conexion = conectar();
        $lista = array();
        //Esta linea es para que puedan mostrarse ñ y acentos
        mysqli_query($conexion, "SET NAMES 'utf8'");
        $sql = "SELECT iddocente, sistema , no_control, nombre, carrera, semestre, round(avg(calificacion)) as prom from estudiante left join inscripcion on estudiante.idestudiante=inscripcion.idestudiante left join curso on inscripcion.idcurso=curso.idcurso left join calificacion on inscripcion.idinscripcion=calificacion.idinscripcion natural join carrera group by nombre having iddocente = '$iddocente' and sistema = '$sistema';" ;
        $consulta = mysqli_query($conexion, $sql) or die(mysqli_error($conexion));

        //Mostramos cada docente en el cuerpo de la tabla
        while ($fila = mysqli_fetch_array($consulta)) {
            $mEstudiante = new Estudiante();      

            $mEstudiante->no_control = $fila['no_control'];
            $mEstudiante->nombre = $fila['nombre'];
            $mEstudiante->carrera = $fila['carrera'];
            $mEstudiante->semestre = $fila['semestre'];
            $mEstudiante->calificacion = $fila['prom'];
            if ($fila['prom'] >= 70) {
                $mEstudiante->situacion = "Aprobado";
            }else {
                $mEstudiante->situacion = "No Aprobado";
            }
            array_push($lista, $mEstudiante);
        }
        return $lista;
    }

    public function obtenerProf($iddocente) {
        $conexion = conectar();
        $lista = array();
        //Esta linea es para que puedan mostrarse ñ y acentos
        mysqli_query($conexion, "SET NAMES 'utf8'");
        $sql = "SELECT nombre_docente from docente where iddocente = '$iddocente';";
        $consulta = mysqli_query($conexion, $sql) or die(mysqli_error($conexion));

        while ($fila = mysqli_fetch_array($consulta)) {
            $mDocente = new Docente();                  
            $mDocente->nombre = $fila['nombre_docente'];            
        }
        return $mDocente;
    }
}
