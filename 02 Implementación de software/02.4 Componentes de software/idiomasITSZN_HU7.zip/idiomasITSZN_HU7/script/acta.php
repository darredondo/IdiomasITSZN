<?php

//Registro de docente
//Coincide con la tabla Docente de MySQL
class Acta {

    public $no_acta = 0;

    public function __construct() {
        
    }
}