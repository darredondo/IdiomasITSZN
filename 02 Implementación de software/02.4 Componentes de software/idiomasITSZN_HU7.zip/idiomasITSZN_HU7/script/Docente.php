<?php

//Registro de docente
//Coincide con la tabla Docente de MySQL
class Docente {

    public $iddocente;
    public $nombre;

    public function __construct() {
        
    }

}