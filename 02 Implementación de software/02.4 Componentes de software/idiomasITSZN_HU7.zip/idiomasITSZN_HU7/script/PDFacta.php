<?php

require_once 'SQL.php';
require_once 'fpdf/fpdf.php'; //Librerías para PDF

class PDF extends FPDF {

    function Titulo($id, $acta) {
        $SQL = new SQL();
        $mDocente = $SQL->obtenerProf($id);
        setlocale(LC_ALL,"Spanish");
        $Dia = strftime("%A, %d");
        $Mes = strftime("%B");
        $Anio = strftime("%Y");

        
        $this->SetFont('Arial', 'B', 14);
        $this->Cell(0, 5, 'Acta No.' . $acta . ' /'. $Anio . '', 0, 0, 'C');
        $this->Ln();
        $this->Ln();
        $this->SetFont('Arial', 'I', 12);
        $this->Cell(0, 5, utf8_decode('     En el Centro de Idiomas del Instituto Tecnológico Superior Zacatecas Norte de Río Grande,'), 0, 0, 'C');
        $this->Ln();
        $this->Cell(0, 5, utf8_decode('Zacatecas, el día '. ucfirst($Dia) .' de '. ucfirst($Mes) .' del '. $Anio .', se recibe lista de calificaciones'), 0, 0, 'C');
        $this->Ln();
        $this->Cell(0, 5, 'finales por parte del ' . utf8_decode($mDocente->nombre) .', quien comparece en calidad de', 0, 0, 'C');
        $this->Ln();
        $this->Cell(0, 5, utf8_decode('docente adscrito al nivel 9 del Centro de Idiomas de dicho Instituto, para avalar las calificaciones'), 0, 0, 'C');
        $this->Ln();
        $this->Cell(0, 5, utf8_decode('de los alumnos listados abajo pertenecientes a las diferentes carreras que oferta el Instituto'), 0, 0, 'C');
        $this->Ln();
        $this->Cell(0, 5, utf8_decode('Tecnológico Superior Zacatecas Norte'), 0, 0, 'C');
        $this->Ln();
        $this->Ln();
        $this->Cell(0, 5, utf8_decode('Consintiendo en que los alumnos que cursen algún plan académico ofertado en el Instituto'), 0, 0, 'C');
        $this->Ln();
        $this->Cell(0, 5, utf8_decode('Tecnológico Superior Zacatecas Norte, se considerará el promedio de la asistencia y aprobación a'), 0, 0, 'C');
        $this->Ln();
        $this->Cell(0, 5, utf8_decode('9 niveles como mínimo, con una calificación aprobatoria mínima para el proceso de acreditación'), 0, 0, 'C');
        $this->Ln();
        $this->Cell(0, 5, utf8_decode('del requisito de lectura, traducción y comprención de artículos técnicos-científicos en una lengua'), 0, 0, 'C');
        $this->Ln();
        $this->Cell(0, 5, utf8_decode('extranjera de 70 (setenta) en una escala de 0 a 100 (Según aspecto Normativo para la acreditación'), 0, 0, 'C');
        $this->Ln();
        $this->Cell(0, 5, utf8_decode('De Lengua Extranjera/Codigo:SNEST-AC-DN-009), en los diferentes niveles que oferta el Instituto'), 0, 0, 'C');
        $this->Ln();
        $this->Cell(0, 5, utf8_decode('en la lengua extranjera(inglés)'), 0, 0, 'C');        
        $this->Ln(20);        
    }

    function Cuerpo($id, $sistema) {
        $SQL = new SQL();
        $lista = $SQL->obtenerEstudiante($id, $sistema);
        //Mostramos cada docente en una tabla en el PDF
        $this->SetFont('Arial', '', 7.5);
        // Cabecera, cada par es el titulo y ancho de cada columna
        $encabezados = array(
            "No. Control" => 15,
            "Nombre" => 45.5,
            "Carrera" => 97,
            "Semestre" => 15,
            "Calificacion" => 15,
            "Situacion" => 17.5,
        );

        foreach ($encabezados as $titulo => $ancho) {
            $this->Cell($ancho, 7, $titulo, 1);
        }
        $this->Ln();
        //Filas de datos
        foreach ($lista as $mEstudiante) {        
            $this->Cell(15, 7, utf8_decode($mEstudiante->no_control), 1);
            $this->Cell(45.5, 7, utf8_decode($mEstudiante->nombre), 1);
            $this->Cell(97, 7, utf8_decode($mEstudiante->carrera), 1);
            $this->Cell(15, 7, utf8_decode($mEstudiante->semestre), 1);
            $this->Cell(15, 7, utf8_decode($mEstudiante->calificacion), 1);
            $this->Cell(17.5, 7, utf8_decode($mEstudiante->situacion), 1);

            $this->Ln();
        }
    }

    function PiePagina($id) {
        $SQL = new SQL();
        $mDocente = $SQL->obtenerProf($id);
        setlocale(LC_ALL,"Spanish");
        $Dia = strftime("%A, %d");
        $Mes = strftime("%B");
        $Anio = strftime("%Y");

        $this->SetFont('Arial','' , 10);
        $this->Ln(5);
        $this->Cell(200, 0, utf8_decode('En la ciudad de Río Grande, Zacatecas, a '. ucfirst($Dia) . ' del mes de '. ucfirst($Mes) . ' del año '. $Anio), 0, 0, 'C');
        $this->Ln(10);
        $this->SetFont('Arial','B' , 10);
        $this->Cell(95, 0, 'ATENTAMENTE', 0, 0, 'C');
        $this->Cell(95, 0, 'ATENTAMENTE', 0, 0, 'C');
        $this->Ln(10);
        $this->SetFont('Arial','' , 10);
        $this->Cell(95, 10, '____________________________________', 0, 0, 'C');
        $this->Cell(95, 10, '____________________________________', 0, 0, 'C');
        $this->Ln(5);
        $this->Cell(95, 10, utf8_decode($mDocente->nombre), 0, 0, 'C');
        $this->Cell(95, 10, 'MARTHA PATRICIA OZORNIO GONZALEZ', 0, 0, 'C');        
        $this->Ln(5);
        $this->Cell(95, 10, 'Docente de la Unidad', 0, 0, 'C');
        $this->Cell(95, 10, 'JEFE DEL DEPARTAMENTO DE SERVICIOS ESCOLARES', 0, 0, 'C');
    }

}

if (isset($_GET['iddocente']) && isset($_GET['sistema']) && isset($_GET['acta'])){
    $iddocente = $_GET['iddocente'];
    $sistema = $_GET['sistema'];
    $acta = $_GET['acta'];

    //Generar el PDF
    $pdf = new PDF();
    $pdf->SetMargins(3, 15, 3);
    $pdf->AddPage();
    $pdf->Titulo($iddocente, $acta);
    $pdf->Cuerpo($iddocente, $sistema);
    $pdf->PiePagina($iddocente);
    $pdf->Output();
}else {
    echo "Imposible generar calificaci&oacute;n estudiante inexistente";
}