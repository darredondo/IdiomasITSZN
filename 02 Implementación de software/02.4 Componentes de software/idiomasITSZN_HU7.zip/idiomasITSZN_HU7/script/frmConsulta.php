<H1>Listado de Nivel 9</H1>

<TABLE id=tabla_docente>
    <THEAD>
        <TR>            
            <TH>Docente</TH>
            <TH>Sistema</TH>
            <TH>Operaciones</TH>
        </TR>   
    </THEAD>
    <TBODY>
        <?php
        $conexion = mysqli_connect("localhost", "user_idiomas", "secret@", "idiomas");
        mysqli_query($conexion,"SET NAMES 'utf8'");
        $sql = "select iddocente, nombre_docente, sistema, nivel_curso from docente natural join curso where nivel_curso=9;";
        $consulta = mysqli_query($conexion, $sql) or die(mysqli_error());
        while ($fila = mysqli_fetch_array($consulta)) {
            echo "<TR>";            
            echo "<TD>" . $fila[1] . "</TD>";
            echo "<TD>" . $fila[2] . "</TD>";
            echo "<TD> <input type=button iddocente='" . $fila['iddocente']. "' sistema='" . $fila['sistema'] . "' value='Generar Acta' class='BTNImprimir btn btn-primary'></TD>";
            echo "</TR>";
        }
        ?>
    </TBODY>
</TABLE>

<SCRIPT>
    $(document).ready(function () {
        $("#tabla_docente").DataTable({
            "bFilter": true,
            "bPaginate": true,
            "bSort": true,
            "bInfo": true
        });
    });
</SCRIPT>