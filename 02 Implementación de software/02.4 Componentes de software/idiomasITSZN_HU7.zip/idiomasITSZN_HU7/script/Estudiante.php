<?php

//Registro de docente
//Coincide con la tabla Docente de MySQL
class Estudiante {

    public $idestudiante;
    public $no_control;
    public $nombre;
    public $carrera;
    public $semestre;    
    public $calificacion;
    public $idusuario;
    public $situacion;

    public function __construct() {
        
    }

}